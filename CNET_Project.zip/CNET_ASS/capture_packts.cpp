#define HAVE_REMOTE
#include <winsock2.h>
#include <ws2tcpip.h>
#include <pcap.h>
#include <iostream>
#include <string>
#include <map>
#include <sqlite3.h>
#include <ctime>
#include <thread>
#include <chrono>
#include <mutex>
#include <atomic>
#include <filesystem>
#include <sstream>
#include <iomanip>
std::atomic<bool> running{true};

// Global signal handler function
BOOL WINAPI ConsoleHandler(DWORD ctrlType) {
    if (ctrlType == CTRL_C_EVENT) {
        running.store(false);
        return TRUE;
    }
    return FALSE;
}
// Define protocol headers for Windows
#pragma pack(push, 1)
struct ip_header {
    unsigned char ip_header_len:4;
    unsigned char ip_version:4;
    unsigned char ip_tos;
    unsigned short ip_total_length;
    unsigned short ip_id;
    unsigned short ip_frag_offset;
    unsigned char ip_ttl;
    unsigned char ip_protocol;
    unsigned short ip_checksum;
    unsigned int ip_srcaddr;
    unsigned int ip_destaddr;
};

struct tcp_header {
    unsigned short source_port;
    unsigned short dest_port;
    unsigned int sequence;
    unsigned int acknowledge;
    unsigned char ns:1;
    unsigned char reserved_part1:3;
    unsigned char data_offset:4;
    unsigned char fin:1;
    unsigned char syn:1;
    unsigned char rst:1;
    unsigned char psh:1;
    unsigned char ack:1;
    unsigned char urg:1;
    unsigned char ecn:1;
    unsigned char cwr:1;
    unsigned short window;
    unsigned short checksum;
    unsigned short urgent_pointer;
};

struct udp_header {
    unsigned short source_port;
    unsigned short dest_port;
    unsigned short length;
    unsigned short checksum;
};
#pragma pack(pop)

// Protocol types enum
enum ProtocolType {
    TCP,
    UDP,
    OTHER
};

// Structure to hold protocol-specific metrics
struct ProtocolMetrics {
    int tcp_count = 0;
    int udp_count = 0;
    int other_count = 0;
    std::string hostname;
    int source_port = 0;
    int dest_port = 0;
    int bytes_transferred = 0;
};

// Connection metrics structure
struct ConnectionMetrics {
    int packet_count = 0;
    std::chrono::system_clock::time_point last_update;
    ProtocolMetrics protocol_metrics;
    float bytes_per_second = 0.0;
};

// Global variables
std::atomic<int> total_packets{0};
std::atomic<int> total_bytes{0};
std::map<std::string, ConnectionMetrics> connection_metrics;
std::mutex metrics_mutex;

// Configuration
const int PACKETS_PER_SECOND = 100;
const std::chrono::milliseconds CAPTURE_INTERVAL(1000 / PACKETS_PER_SECOND);

// DNS resolution using Windows API
std::string resolve_hostname(const std::string& ip_addr) {
    struct sockaddr_in sa;
    char host[NI_MAXHOST] = {0};
    
    sa.sin_family = AF_INET;
    sa.sin_addr.s_addr = inet_addr(ip_addr.c_str());
    DWORD hostname_size = sizeof(host);
    
    // Use gethostbyaddr instead of WSALookupServiceName
    struct hostent *host_entry;
    host_entry = gethostbyaddr((char*)&sa.sin_addr, sizeof(sa.sin_addr), AF_INET);
    
    if (host_entry != nullptr) {
        return std::string(host_entry->h_name);
    }
    return ip_addr;
}

// Packet handler function
void packet_handler(u_char *user_data, const struct pcap_pkthdr *pkthdr, const u_char *packet) {
    static auto last_capture = std::chrono::steady_clock::now();
    auto now = std::chrono::steady_clock::now();
    
    if (now - last_capture < CAPTURE_INTERVAL) {
        return;
    }
    last_capture = now;

    std::lock_guard<std::mutex> lock(metrics_mutex);

    // Skip Ethernet header (14 bytes)
    const u_char *ip_packet = packet + 14;
    const ip_header *ih = (ip_header *)ip_packet;

    // Extract IP addresses
    IN_ADDR src_addr, dst_addr;
    src_addr.s_addr = ih->ip_srcaddr;
    dst_addr.s_addr = ih->ip_destaddr;
    
    char src_ip[INET_ADDRSTRLEN];
    char dst_ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &src_addr, src_ip, INET_ADDRSTRLEN);
    inet_ntop(AF_INET, &dst_addr, dst_ip, INET_ADDRSTRLEN);
    
    // Get protocol specific information
    int src_port = 0;
    int dst_port = 0;
    ProtocolType proto_type = OTHER;
    int header_length = (ih->ip_header_len) * 4;
    
    switch(ih->ip_protocol) {
        case IPPROTO_TCP: {
            const tcp_header* th = (tcp_header*)(ip_packet + header_length);
            src_port = ntohs(th->source_port);
            dst_port = ntohs(th->dest_port);
            proto_type = TCP;
            break;
        }
        case IPPROTO_UDP: {
            const udp_header* uh = (udp_header*)(ip_packet + header_length);
            src_port = ntohs(uh->source_port);
            dst_port = ntohs(uh->dest_port);
            proto_type = UDP;
            break;
        }
    }

    // Create connection key
    std::stringstream conn_key;
    conn_key << src_ip << ":" << src_port << "->" << dst_ip << ":" << dst_port;
    std::string connection_key = conn_key.str();

    // Update metrics
    auto& metrics = connection_metrics[connection_key];
    metrics.packet_count++;
    metrics.last_update = std::chrono::system_clock::now();
    metrics.protocol_metrics.bytes_transferred += pkthdr->len;
    
    // Calculate bytes per second
    static auto last_bps_update = std::chrono::steady_clock::now();
    auto time_diff = std::chrono::duration_cast<std::chrono::seconds>(now - last_bps_update).count();
    if (time_diff > 0) {
        metrics.bytes_per_second = metrics.protocol_metrics.bytes_transferred / static_cast<float>(time_diff);
        last_bps_update = now;
    }
    
    // Update protocol metrics
    switch(proto_type) {
        case TCP:
            metrics.protocol_metrics.tcp_count++;
            break;
        case UDP:
            metrics.protocol_metrics.udp_count++;
            break;
        default:
            metrics.protocol_metrics.other_count++;
    }
    
    // Store ports
    metrics.protocol_metrics.source_port = src_port;
    metrics.protocol_metrics.dest_port = dst_port;
    
    // Try to resolve hostname if not already done
    if (metrics.protocol_metrics.hostname.empty()) {
        metrics.protocol_metrics.hostname = resolve_hostname(dst_ip);
    }

    total_packets++;
    total_bytes += pkthdr->len;

    // Log capture
    std::cout << "Packet captured: " << connection_key 
              << " Protocol: " << (proto_type == TCP ? "TCP" : (proto_type == UDP ? "UDP" : "OTHER"))
              << " Size: " << pkthdr->len << " bytes"
              << " Host: " << metrics.protocol_metrics.hostname
              << std::endl;
}

// Store metrics in SQLite database



void store_metrics(sqlite3 *db) {
    std::lock_guard<std::mutex> lock(metrics_mutex);
    
    char *errMsg = nullptr;
    
    // Drop existing table and recreate
    const char* drop_table_sql = "DROP TABLE IF EXISTS metrics;";
    if (sqlite3_exec(db, drop_table_sql, 0, 0, &errMsg) != SQLITE_OK) {
        std::cerr << "Drop table error: " << errMsg << std::endl;
        sqlite3_free(errMsg);
        return;
    }

    const char* create_table_sql = 
        "CREATE TABLE IF NOT EXISTS metrics ("
        "connection TEXT PRIMARY KEY,"
        "packet_count INTEGER,"
        "tcp_count INTEGER,"
        "udp_count INTEGER,"
        "other_count INTEGER,"
        "source_port INTEGER,"
        "dest_port INTEGER,"
        "hostname TEXT,"
        "bytes_transferred INTEGER,"
        "bytes_per_second REAL,"
        "last_update DATETIME"
        ");";

    if (sqlite3_exec(db, create_table_sql, 0, 0, &errMsg) != SQLITE_OK) {
        std::cerr << "Create table error: " << errMsg << std::endl;
        sqlite3_free(errMsg);
        return;
    }

    // Begin transaction
    if (sqlite3_exec(db, "BEGIN TRANSACTION;", 0, 0, &errMsg) != SQLITE_OK) {
        std::cerr << "Transaction begin error: " << errMsg << std::endl;
        sqlite3_free(errMsg);
        return;
    }

    // Prepare insert statement
    sqlite3_stmt* stmt;
    const char* insert_sql = 
        "INSERT INTO metrics ("
        "connection, packet_count, tcp_count, udp_count, other_count, "
        "source_port, dest_port, hostname, bytes_transferred, "
        "bytes_per_second, last_update"
        ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'));";

    if (sqlite3_prepare_v2(db, insert_sql, -1, &stmt, 0) != SQLITE_OK) {
        std::cerr << "Prepare statement error: " << sqlite3_errmsg(db) << std::endl;
        sqlite3_exec(db, "ROLLBACK;", 0, 0, &errMsg);
        return;
    }

    // Insert current metrics
    for (const auto &[conn, metrics] : connection_metrics) {
        sqlite3_bind_text(stmt, 1, conn.c_str(), -1, SQLITE_STATIC);
        sqlite3_bind_int(stmt, 2, metrics.packet_count);
        sqlite3_bind_int(stmt, 3, metrics.protocol_metrics.tcp_count);
        sqlite3_bind_int(stmt, 4, metrics.protocol_metrics.udp_count);
        sqlite3_bind_int(stmt, 5, metrics.protocol_metrics.other_count);
        sqlite3_bind_int(stmt, 6, metrics.protocol_metrics.source_port);
        sqlite3_bind_int(stmt, 7, metrics.protocol_metrics.dest_port);
        sqlite3_bind_text(stmt, 8, metrics.protocol_metrics.hostname.c_str(), -1, SQLITE_STATIC);
        sqlite3_bind_int(stmt, 9, metrics.protocol_metrics.bytes_transferred);
        sqlite3_bind_double(stmt, 10, metrics.bytes_per_second);
        
        if (sqlite3_step(stmt) != SQLITE_DONE) {
            std::cerr << "Insert error: " << sqlite3_errmsg(db) << std::endl;
        }
        sqlite3_reset(stmt);
        sqlite3_clear_bindings(stmt);
    }

    sqlite3_finalize(stmt);

    // Commit transaction
    if (sqlite3_exec(db, "COMMIT;", 0, 0, &errMsg) != SQLITE_OK) {
        std::cerr << "Commit error: " << errMsg << std::endl;
        sqlite3_free(errMsg);
        sqlite3_exec(db, "ROLLBACK;", 0, 0, &errMsg);
        return;
    }
}








void periodic_store_metrics(sqlite3 *db) {
    while (true) {
        store_metrics(db);
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
}

void list_devices() {
    pcap_if_t *alldevs;
    char errbuf[PCAP_ERRBUF_SIZE];
    
    if (pcap_findalldevs(&alldevs, errbuf) == -1) {
        std::cerr << "Error finding devices: " << errbuf << std::endl;
        return;
    }
    
    std::cout << "\nAvailable Network Devices:\n";
    pcap_if_t *d;
    int i = 0;
    for (d = alldevs; d; d = d->next) {
        std::cout << ++i << ". " << (d->description ? d->description : "No description") 
                  << "\n   Name: " << d->name << std::endl;
    }
    
    pcap_freealldevs(alldevs);
}





int main() {
    // Initialize Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "Failed to initialize Winsock" << std::endl;
        return 1;
    }

    // Set up database path
    std::filesystem::path currentPath = std::filesystem::current_path();
    std::string db_path = (currentPath / "network_metrics.db").string();
    std::cout << "Using database at: " << db_path << std::endl;

    // List and select network device
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_if_t *alldevs;
    pcap_if_t *d;

    list_devices();

    if (pcap_findalldevs(&alldevs, errbuf) == -1) {
        std::cerr << "Error finding devices: " << errbuf << std::endl;
        WSACleanup();
        return 1;
    }
    
    d = alldevs;
    if (!d) {
        std::cerr << "No network devices found!" << std::endl;
        WSACleanup();
        return 1;
    }

    std::cout << "\nOpening device: " << d->name << std::endl;
    pcap_t *handle = pcap_open_live(d->name, BUFSIZ, 1, 1000, errbuf);
    if (handle == nullptr) {
        std::cerr << "Couldn't open device: " << errbuf << std::endl;
        pcap_freealldevs(alldevs);
        WSACleanup();
        return 1;
    }

    // Initialize SQLite database
    sqlite3 *db;
    if (sqlite3_open(db_path.c_str(), &db) != SQLITE_OK) {
        std::cerr << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
        pcap_close(handle);
        pcap_freealldevs(alldevs);
        WSACleanup();
        return 1;
    }

    // Start metrics storage thread
    std::cout << "Starting metrics storage thread..." << std::endl;
    std::thread storage_thread(periodic_store_metrics, db);
    storage_thread.detach();

    std::cout << "\nNetwork Traffic Monitor Started" << std::endl;
    std::cout << "=============================" << std::endl;
    std::cout << "Press Ctrl+C to stop capturing" << std::endl;

    // Set up signal handling for Ctrl+C
    if (!SetConsoleCtrlHandler(ConsoleHandler, TRUE)) {
        std::cerr << "Could not set control handler" << std::endl;
        return 1;
    }

    // Start packet capture
    int res;
    struct pcap_pkthdr *header;
    const u_char *pkt_data;

    while (running) {
        res = pcap_next_ex(handle, &header, &pkt_data);
        if (res == 0) {
            // Timeout elapsed
            continue;
        } else if (res == -1) {
            std::cerr << "Error reading packet: " << pcap_geterr(handle) << std::endl;
            break;
        } else if (res == -2) {
            break;
        }

        packet_handler(nullptr, header, pkt_data);
    }

    // Perform final metrics storage
    std::cout << "\nPerforming final metrics storage..." << std::endl;
    store_metrics(db);

    // Print final statistics
    std::cout << "\nFinal Statistics:" << std::endl;
    std::cout << "=================" << std::endl;
    std::cout << "Total Packets Captured: " << total_packets << std::endl;
    std::cout << "Total Bytes Transferred: " << total_bytes << std::endl;

    // Print connection statistics
    std::cout << "\nActive Connections:" << std::endl;
    std::cout << "==================" << std::endl;
    {
        std::lock_guard<std::mutex> lock(metrics_mutex);
        for (const auto& [conn, metrics] : connection_metrics) {
            std::cout << "Connection: " << conn << std::endl;
            std::cout << "  Packets: " << metrics.packet_count << std::endl;
            std::cout << "  TCP Packets: " << metrics.protocol_metrics.tcp_count << std::endl;
            std::cout << "  UDP Packets: " << metrics.protocol_metrics.udp_count << std::endl;
            std::cout << "  Bytes Transferred: " << metrics.protocol_metrics.bytes_transferred << std::endl;
            std::cout << "  Bytes/Second: " << std::fixed << std::setprecision(2) 
                      << metrics.bytes_per_second << std::endl;
            std::cout << "-------------------" << std::endl;
        }
    }

    // Cleanup resources
    std::cout << "\nCleaning up resources..." << std::endl;

    // Close database
    sqlite3_close(db);
    std::cout << "Database closed" << std::endl;

    // Close packet capture
    pcap_close(handle);
    std::cout << "Packet capture stopped" << std::endl;

    // Free device list
    pcap_freealldevs(alldevs);
    std::cout << "Device list freed" << std::endl;

    // Cleanup Winsock
    WSACleanup();
    std::cout << "Winsock cleaned up" << std::endl;

    std::cout << "\nNetwork Traffic Monitor Shutdown Complete" << std::endl;
    
    return 0;
}