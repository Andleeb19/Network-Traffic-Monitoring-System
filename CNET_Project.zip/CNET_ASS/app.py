from flask import Flask, render_template, jsonify
import sqlite3
import time
import os
import traceback
from datetime import datetime

app = Flask(__name__)

# Use the database file in the current directory
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'build', 'network_metrics.db')

def init_db():
    print(f"Using database at: {DB_PATH}")
    try:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute('''CREATE TABLE IF NOT EXISTS metrics (
                            connection TEXT PRIMARY KEY,
                            packet_count INTEGER,
                            tcp_count INTEGER,
                            udp_count INTEGER,
                            other_count INTEGER,
                            source_port INTEGER,
                            dest_port INTEGER,
                            hostname TEXT,
                            bytes_transferred INTEGER,
                            bytes_per_second REAL,
                            last_update DATETIME
                            )''')
            conn.commit()
    except Exception as e:
        print(f"Database initialization error: {e}")

def format_bytes(bytes_value):
    try:
        bytes_value = float(bytes_value)
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_value < 1024:
                return f"{bytes_value:.2f} {unit}"
            bytes_value /= 1024
        return f"{bytes_value:.2f} PB"
    except (TypeError, ValueError):
        return "0 B"

def fetch_metrics():
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT * FROM metrics 
                ORDER BY bytes_transferred DESC
            """)
            rows = cursor.fetchall()
            
            metrics = [{
                'connection': row['connection'],
                'packet_count': row['packet_count'],
                'tcp_count': row['tcp_count'],
                'udp_count': row['udp_count'],
                'other_count': row['other_count'],
                'hostname': row['hostname'],
                'bytes_transferred': row['bytes_transferred'],
                'formatted_bytes': format_bytes(row['bytes_transferred']),
                'bytes_per_second': row['bytes_per_second'],
                'formatted_rate': format_bytes(row['bytes_per_second']) + '/s'
            } for row in rows]

            # Calculate totals
            total_packets = sum(m['packet_count'] for m in metrics)
            total_bytes = sum(m['bytes_transferred'] for m in metrics)
            total_tcp = sum(m['tcp_count'] for m in metrics)
            total_udp = sum(m['udp_count'] for m in metrics)
            total_other = sum(m['other_count'] for m in metrics)
            total_protocols = max(total_tcp + total_udp + total_other, 1)  # Avoid division by zero
            
            return {
                'connections': len(metrics),
                'total_packets': total_packets,
                'total_bytes': total_bytes,
                'formatted_total_bytes': format_bytes(total_bytes),
                'current_transfer_rate': format_bytes(sum(m['bytes_per_second'] for m in metrics)) + '/s',
                'protocol_distribution': {
                    'tcp': round(total_tcp / total_protocols * 100, 2),
                    'udp': round(total_udp / total_protocols * 100, 2),
                    'other': round(total_other / total_protocols * 100, 2)
                },
                'protocol_counts': {
                    'tcp': total_tcp,
                    'udp': total_udp,
                    'other': total_other
                },
                'metrics': metrics,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
    except sqlite3.OperationalError as e:
        print(f"Database operation error: {e}")
        traceback.print_exc()
        return {
            'connections': 0,
            'total_packets': 0,
            'total_bytes': 0,
            'formatted_total_bytes': '0 B',
            'current_transfer_rate': '0 B/s',
            'protocol_distribution': {'tcp': 0, 'udp': 0, 'other': 0},
            'protocol_counts': {'tcp': 0, 'udp': 0, 'other': 0},
            'metrics': [],
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
    except Exception as e:
        print(f"Unexpected error: {e}")
        traceback.print_exc()
        return {
            'connections': 0,
            'total_packets': 0,
            'metrics': [],
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/metrics')
def metrics():
    try:
        data = fetch_metrics()
        return jsonify(data)
    except Exception as e:
        print(f"Error in metrics route: {e}")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    init_db()
    print("Network Traffic Monitor Web Interface")
    print("====================================")
    print(f"Database Path: {DB_PATH}")
    print("Server starting at http://127.0.0.1:5000")
    print("Press Ctrl+C to stop the server")
    app.run(debug=True, host='127.0.0.1', port=5000)